

'''
Will train a set of data to predict values in the test set
'''

class Train:
    
    '''
    Initiate class Train
    
    @param name - name of file 
    
    '''
    def __init__(self, name):
        self.name = name
     
     
    def printName(self):
        print(self.name)